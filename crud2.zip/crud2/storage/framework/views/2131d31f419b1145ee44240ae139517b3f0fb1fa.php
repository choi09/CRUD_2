<!DOCTYPE html>
<html>
<head>
    <title>Data SISWA SMK</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
</head>
<body>
    <div class="container">
    <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\crud2\resources\views/layout/master.blade.php ENDPATH**/ ?>